package com.ims.jpgtosketsa

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.File
import kotlin.math.max

class MainActivity : Activity() {
    private val cInk = 0xFF111111.toInt()
    private val cYellow = 0xFFFFC107.toInt()
    private val cBg = 0xFFFFF8E7.toInt()
    private val cField = 0xFFF4EFE0.toInt()
    private val cMuted = 0xFF6B6558.toInt()
    private val cDanger = 0xFFE5484D.toInt()

    // Status bersama
    private var srcUri: Uri? = null
    private var base: Bitmap? = null
    private var result: Bitmap? = null
    private var savedUri: Uri? = null
    private var videoUri: Uri? = null
    private var gen = 0
    private var tab = 0
    private var mode = 0
    private var autoMode = true
    private val manualVals = intArrayOf(40, 70, 75, 55)
    @Volatile private var cancelFlag = false
    private val handler = Handler(Looper.getMainLooper())
    private val job = Runnable { renderPreview() }

    // Umum
    private lateinit var preview: ImageView
    private lateinit var hint: TextView
    private lateinit var tabBtns: List<Button>
    private lateinit var pageSketch: LinearLayout
    private lateinit var pagePaint: LinearLayout

    // Tab Sketsa
    private lateinit var chips: List<Button>
    private lateinit var colorBox: LinearLayout
    private lateinit var autoBtns: List<Button>
    private lateinit var skBlur: SeekBar
    private lateinit var skDark: SeekBar
    private lateinit var skColor: SeekBar
    private lateinit var skGrain: SeekBar
    private lateinit var skPaper: Spinner
    private lateinit var skSave: Button
    private lateinit var skShare: Button
    private lateinit var skToVideo: Button
    private lateinit var skStatus: TextView

    // Tab SpeedPaint
    private lateinit var useSketch: CheckBox
    private lateinit var spStyle: Spinner
    private lateinit var spDir: Spinner
    private lateinit var spPaper: Spinner
    private lateinit var spInk: Spinner
    private lateinit var spRatio: Spinner
    private lateinit var spRes: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spHold: Spinner
    private lateinit var spSource: Spinner
    private lateinit var spSens: Spinner
    private lateinit var spThick: Spinner
    private lateinit var seekDur: SeekBar
    private lateinit var seekHand: SeekBar
    private lateinit var seekSpeed: SeekBar
    private lateinit var handCheck: CheckBox
    private lateinit var handInfo: TextView
    private lateinit var generate: Button
    private lateinit var cancel: Button
    private lateinit var bar: ProgressBar
    private lateinit var pStatus: TextView
    private lateinit var watch: Button
    private lateinit var shareVideo: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(2), stroke)
    }

    private fun lp(top: Int = 0, h: Int = -2) = LinearLayout.LayoutParams(-1, h).apply { topMargin = dp(top) }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 18, cInk)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(TextView(this).apply { text = title; textSize = 16f; setTypeface(typeface, Typeface.BOLD); setTextColor(cInk) })
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(12), dp(14), 0) })
        return c
    }

    private fun button(text: String, bg: Int, fg: Int = cInk) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(fg)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(bg, 14, cInk); stateListAnimator = null
    }

    private fun spinner(p: LinearLayout, label: String, items: List<String>, sel: Int = 0): Spinner {
        p.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(10), 0, dp(4)) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
        val box = FrameLayout(this).apply { background = rounded(cField, 12); setPadding(dp(6), 0, dp(6), 0) }
        box.addView(sp, FrameLayout.LayoutParams(-1, dp(46)))
        p.addView(box)
        return sp
    }

    private fun seekRow(p: LinearLayout, label: (Int) -> String, mx: Int, init: Int, live: Boolean = false): Pair<LinearLayout, SeekBar> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(this).apply { text = label(init); textSize = 13f; setTextColor(cInk); setPadding(dp(2), dp(12), 0, 0) }
        val sb = SeekBar(this).apply {
            max = mx; progress = init
            progressTintList = ColorStateList.valueOf(cInk)
            thumbTintList = ColorStateList.valueOf(cYellow)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { tv.text = label(v); if (live) schedule() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv); box.addView(sb)
        p.addView(box)
        return Pair(box, sb)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = cBg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(28)) }

        // Header logo
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                val r = dp(26).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
            elevation = dp(4).toFloat()
        }
        header.addView(ImageView(this).apply {
            setImageResource(resources.getIdentifier("logo_header", "drawable", packageName))
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(-1, dp(150)))
        col.addView(header)

        // Tab
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabBtns = listOf(button("\u270F\uFE0F Sketsa", Color.WHITE), button("\uD83C\uDFAC SpeedPaint", Color.WHITE))
        tabBtns.forEachIndexed { i, t ->
            tabRow.addView(t, LinearLayout.LayoutParams(0, dp(50), 1f).apply { if (i > 0) leftMargin = dp(8) })
            t.setOnClickListener { selectTab(i) }
        }
        col.addView(tabRow, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(14), dp(14), 0) })

        // Foto (bersama)
        val c1 = card(col, "Foto")
        val pick = button("Pilih Foto dari Galeri", cYellow)
        c1.addView(pick, lp(10, dp(50)))
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        hint = TextView(this).apply { text = "Belum ada foto"; setTextColor(cMuted); gravity = Gravity.CENTER }
        val pbox = FrameLayout(this).apply { background = rounded(cField, 14); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        pbox.addView(hint, FrameLayout.LayoutParams(-1, -1))
        pbox.addView(preview, FrameLayout.LayoutParams(-1, -1))
        c1.addView(pbox, lp(12, dp(320)))
        c1.addView(TextView(this).apply { text = "Di tab Sketsa, tahan gambar untuk melihat foto asli"; textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(8), 0, 0) })

        pageSketch = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pagePaint = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pageSketch); col.addView(pagePaint)
        buildSketchPage()
        buildPaintPage()

        setContentView(ScrollView(this).apply { setBackgroundColor(cBg); addView(col) })
        selectMode(0)
        selectAuto(true)
        selectTab(0)
        refreshHandInfo()

        preview.setOnTouchListener { _, e ->
            if (tab == 0) when (e.action) {
                MotionEvent.ACTION_DOWN -> base?.let { preview.setImageBitmap(it) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> result?.let { preview.setImageBitmap(it) }
            }
            true
        }
        pick.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 1) }
    }

    // ---------------- Tab Sketsa ----------------
    private fun buildSketchPage() {
        val c2 = card(pageSketch, "Gaya sketsa")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("\u270F\uFE0F Hitam-Putih", "\uD83C\uDFA8 Berwarna", "\uD83D\uDD8A\uFE0F Garis Tegas")
        chips = names.map { button(it, Color.WHITE).apply { textSize = 13f; setPadding(dp(4), 0, dp(4), 0) } }
        chips.forEachIndexed { i, btn ->
            row.addView(btn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { if (i > 0) leftMargin = dp(6) })
            btn.setOnClickListener { selectMode(i) }
        }
        c2.addView(row, lp(10))

        val c3 = card(pageSketch, "Atur hasil")
        val arow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        autoBtns = listOf(button("Auto", Color.WHITE), button("Manual", Color.WHITE))
        autoBtns.forEachIndexed { i, btn ->
            arow.addView(btn, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (i > 0) leftMargin = dp(6) })
            btn.setOnClickListener { selectAuto(i == 0) }
        }
        c3.addView(arow, lp(10))
        c3.addView(TextView(this).apply {
            text = "Auto: ketebalan 40%, kegelapan 70%, tekstur kertas 55%"
            textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(8), 0, 0)
        })
        skBlur = seekRow(c3, { "Ketebalan / kehalusan garis: $it%" }, 100, 40, true).second
        skDark = seekRow(c3, { "Kegelapan: $it%" }, 100, 70, true).second
        val cr = seekRow(c3, { "Kekuatan warna: $it%" }, 100, 75, true)
        colorBox = cr.first; skColor = cr.second
        skGrain = seekRow(c3, { "Tekstur kertas: $it%" }, 100, 55, true).second
        skPaper = spinner(c3, "Latar kertas", listOf("Kertas putih", "Kertas krem", "Papan tulis (kapur)"))
        skPaper.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { schedule() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), 0) }
        skSave = button("Simpan Sketsa ke Galeri", cYellow).apply { textSize = 16f; alpha = 0.5f; isEnabled = false }
        skShare = button("Bagikan Sketsa", Color.WHITE).apply { alpha = 0.5f; isEnabled = false }
        skToVideo = button("\uD83C\uDFAC Jadikan Video SpeedPaint", Color.WHITE).apply { alpha = 0.5f; isEnabled = false }
        skStatus = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(cInk); textSize = 14f }
        act.addView(skSave, lp(0, dp(54)))
        act.addView(skShare, lp(8, dp(48)))
        act.addView(skToVideo, lp(8, dp(48)))
        act.addView(skStatus, lp(10))
        pageSketch.addView(act)
        skSave.setOnClickListener { saveSketch(false) }
        skShare.setOnClickListener { if (savedUri != null) shareImage(savedUri!!) else saveSketch(true) }
        skToVideo.setOnClickListener { useSketch.isChecked = true; selectTab(1) }
    }

    private fun selectAuto(a: Boolean) {
        val sbs = listOf(skBlur, skDark, skColor, skGrain)
        if (a && !autoMode) sbs.forEachIndexed { i, s -> manualVals[i] = s.progress }
        autoMode = a
        val v = if (a) intArrayOf(40, 70, 75, 55) else manualVals
        sbs.forEachIndexed { i, s -> s.progress = v[i]; s.isEnabled = !a; s.alpha = if (a) 0.45f else 1f }
        autoBtns.forEachIndexed { k, btn -> btn.background = rounded(if ((k == 0) == a) cYellow else Color.WHITE, 14, cInk) }
        schedule()
    }

    private fun selectMode(i: Int) {
        mode = i
        chips.forEachIndexed { k, btn -> btn.background = rounded(if (k == i) cYellow else Color.WHITE, 14, cInk) }
        colorBox.visibility = if (i == 1) View.VISIBLE else View.GONE
        schedule()
    }

    private fun sketchParams() = SketchParams(mode, skBlur.progress, skDark.progress, skColor.progress, skGrain.progress, skPaper.selectedItemPosition)

    private fun schedule() {
        handler.removeCallbacks(job)
        handler.postDelayed(job, 150)
    }

    private fun updatePreview() {
        val show = if (tab == 0 || useSketch.isChecked) (result ?: base) else base
        if (show != null) preview.setImageBitmap(show)
    }

    private fun renderPreview() {
        val bm = base ?: return
        val p = sketchParams()
        val g = ++gen
        Thread {
            try {
                val r = Sketcher.render(bm, p)
                runOnUiThread { if (g == gen) { result = r; savedUri = null; updatePreview() } }
            } catch (e: Throwable) {
                runOnUiThread { skStatus.text = "Gagal: ${e.message}" }
            }
        }.start()
    }

    private fun saveSketch(thenShare: Boolean) {
        val u = srcUri ?: return
        val p = sketchParams()
        skStatus.text = "Menyimpan..."
        Thread {
            try {
                val out = Sketcher.render(decode(u, 2048), p)
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "sketsa_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JPG to Sketsa")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)!!.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                savedUri = uri
                runOnUiThread {
                    skStatus.text = "Tersimpan di Pictures/JPG to Sketsa"
                    if (thenShare) shareImage(uri)
                }
            } catch (e: Throwable) {
                runOnUiThread { skStatus.text = "Gagal menyimpan: ${e.message}" }
            }
        }.start()
    }

    private fun shareImage(uri: Uri) {
        val i = Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Bagikan sketsa"))
    }

    // ---------------- Tab SpeedPaint ----------------
    private fun buildPaintPage() {
        val cs = card(pagePaint, "Sumber gambar")
        useSketch = CheckBox(this).apply {
            text = "Pakai hasil sketsa dari tab Sketsa"; setTextColor(cInk)
            buttonTintList = ColorStateList.valueOf(cInk)
            setOnCheckedChangeListener { _, _ -> updatePreview() }
        }
        cs.addView(useSketch, lp(6))

        val c2 = card(pagePaint, "Gaya menggambar")
        spStyle = spinner(c2, "Gaya", listOf("Ikuti garis, lalu warna", "Langsung warna (menyapu)", "Ikuti garis saja", "Langsung warna, ikuti garis"))
        spDir = spinner(c2, "Arah", listOf("Kiri ke kanan", "Atas ke bawah", "Dari tengah keluar"))
        spPaper = spinner(c2, "Latar kertas", listOf("Putih", "Krem", "Papan tulis", "Kertas buku bergaris"))
        spInk = spinner(c2, "Warna goresan sketsa", listOf("Otomatis (hitam / putih)", "Biru tua (pulpen)", "Cokelat sepia", "Abu-abu pensil", "Warna asli foto"))

        val c3 = card(pagePaint, "Video")
        seekDur = seekRow(c3, { "Durasi: ${it + 5} detik" }, 55, 10).second
        spRatio = spinner(c3, "Rasio video", listOf("Sesuai foto", "9:16 (Reels/TikTok)", "1:1 (Instagram)", "16:9 (YouTube)"))
        spRes = spinner(c3, "Resolusi", listOf("720p", "1080p"))
        spFps = spinner(c3, "FPS video", listOf("24 fps", "30 fps", "60 fps"), 1)
        spHold = spinner(c3, "Tahan hasil akhir", listOf("0 detik", "1 detik", "2 detik", "3 detik"), 1)

        val c4 = card(pagePaint, "Deteksi garis")
        spSource = spinner(c4, "Sumber garis", listOf("Otomatis (hitam-putih / foto)", "Tepi saja (untuk foto)", "Area gelap (gambar hitam-putih)"))
        spSens = spinner(c4, "Kepekaan garis", listOf("Otomatis (sesuai gambar)", "Lebih sedikit garis", "Lebih banyak garis"))
        spThick = spinner(c4, "Ketebalan garis", listOf("Otomatis (sesuai gambar)", "Tipis", "Sedang", "Tebal"))

        val c5 = card(pagePaint, "Tangan")
        handCheck = CheckBox(this).apply {
            text = "Tampilkan gambar tangan"; isChecked = true; setTextColor(cInk)
            buttonTintList = ColorStateList.valueOf(cInk)
        }
        c5.addView(handCheck, lp(6))
        seekHand = seekRow(c5, { "Ukuran tangan: ${it + 20}%" }, 80, 35).second
        seekSpeed = seekRow(c5, { "Kecepatan gerak tangan: x${(it + 5) / 10f}" }, 25, 5).second
        handInfo = TextView(this).apply { textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(10), 0, 0) }
        c5.addView(handInfo)
        val hb = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val loadHandBtn = button("Ganti tangan (PNG)", Color.WHITE)
        val resetHandBtn = button("Bawaan", Color.WHITE)
        hb.addView(loadHandBtn, LinearLayout.LayoutParams(0, dp(46), 2f).apply { rightMargin = dp(8) })
        hb.addView(resetHandBtn, LinearLayout.LayoutParams(0, dp(46), 1f))
        c5.addView(hb, lp(10))
        handCheck.setOnCheckedChangeListener { _, on ->
            seekHand.isEnabled = on; seekSpeed.isEnabled = on
            loadHandBtn.isEnabled = on; resetHandBtn.isEnabled = on
            loadHandBtn.alpha = if (on) 1f else 0.4f; resetHandBtn.alpha = if (on) 1f else 0.4f
        }
        loadHandBtn.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 2) }
        resetHandBtn.setOnClickListener { File(filesDir, "hand_custom.png").delete(); refreshHandInfo() }

        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), 0) }
        generate = button("\u25B6  Buat Video Speedpaint", cYellow).apply { textSize = 16f; alpha = 0.5f; isEnabled = false }
        cancel = button("Batalkan", Color.WHITE, cDanger).apply { visibility = View.GONE }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE; progressTintList = ColorStateList.valueOf(cInk)
        }
        pStatus = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(cInk); textSize = 14f }
        watch = button("Putar Video", cYellow).apply { visibility = View.GONE }
        shareVideo = button("Bagikan Video", Color.WHITE).apply { visibility = View.GONE }
        act.addView(generate, lp(0, dp(56)))
        act.addView(cancel, lp(8, dp(48)))
        act.addView(bar, lp(12))
        act.addView(pStatus, lp(8))
        act.addView(watch, lp(10, dp(50)))
        act.addView(shareVideo, lp(8, dp(50)))
        pagePaint.addView(act)
        generate.setOnClickListener { startRender() }
        cancel.setOnClickListener { cancelFlag = true; pStatus.text = "Membatalkan..." }
        watch.setOnClickListener {
            videoUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        shareVideo.setOnClickListener {
            videoUri?.let {
                val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, it)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, "Bagikan video"))
            }
        }
    }

    private fun refreshHandInfo() {
        handInfo.text = if (File(filesDir, "hand_custom.png").exists()) "Tangan: gambar pilihan Anda" else "Tangan: bawaan"
    }

    private fun loadHand(): Bitmap? {
        if (!handCheck.isChecked) return null
        val f = File(filesDir, "hand_custom.png")
        if (f.exists()) {
            val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bo)
            val ss = max(1, bo.outWidth / 1600)
            return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = ss })
        }
        val id = resources.getIdentifier("hand", "drawable", packageName)
        return if (id != 0) BitmapFactory.decodeResource(resources, id) else null
    }

    private fun startRender() {
        val u = srcUri ?: return
        val secs = seekDur.progress + 5
        val opts = PaintOptions(
            style = spStyle.selectedItemPosition,
            direction = spDir.selectedItemPosition,
            paper = spPaper.selectedItemPosition,
            ratio = spRatio.selectedItemPosition,
            res = if (spRes.selectedItemPosition == 1) 1080 else 720,
            handPct = seekHand.progress + 20,
            handSpeed = (seekSpeed.progress + 5) / 10f,
            holdSec = spHold.selectedItemPosition,
            fps = intArrayOf(24, 30, 60)[spFps.selectedItemPosition],
            sens = spSens.selectedItemPosition,
            thick = spThick.selectedItemPosition,
            source = spSource.selectedItemPosition,
            ink = spInk.selectedItemPosition
        )
        val sp = sketchParams()
        val fromSketch = useSketch.isChecked
        val hand = loadHand()
        cancelFlag = false
        generate.isEnabled = false; generate.alpha = 0.5f
        cancel.visibility = View.VISIBLE
        watch.visibility = View.GONE; shareVideo.visibility = View.GONE
        bar.progress = 0; bar.visibility = View.VISIBLE
        pStatus.text = "Membuat video..."
        Thread {
            try {
                var bmp = decode(u, 1600)
                if (fromSketch) bmp = Sketcher.render(bmp, sp)
                val tmp = File(cacheDir, "speedpaint.mp4")
                SpeedPaint.render(bmp, secs, tmp, opts, hand, { cancelFlag }) { p -> runOnUiThread { bar.progress = p } }
                if (cancelFlag) {
                    tmp.delete()
                    runOnUiThread { pStatus.text = "Dibatalkan" }
                } else {
                    val cv = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "speedpaint_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SpeedPaint")
                    }
                    val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                    videoUri = uri
                    runOnUiThread {
                        pStatus.text = "Selesai! Tersimpan di Movies/SpeedPaint"
                        watch.visibility = View.VISIBLE; shareVideo.visibility = View.VISIBLE
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { pStatus.text = "Gagal: ${e.message}" }
            } finally {
                runOnUiThread { generate.isEnabled = true; generate.alpha = 1f; cancel.visibility = View.GONE; bar.visibility = View.GONE }
            }
        }.start()
    }

    // ---------------- Umum ----------------
    private fun selectTab(i: Int) {
        tab = i
        tabBtns.forEachIndexed { k, t -> t.background = rounded(if (k == i) cYellow else Color.WHITE, 14, cInk) }
        pageSketch.visibility = if (i == 0) View.VISIBLE else View.GONE
        pagePaint.visibility = if (i == 1) View.VISIBLE else View.GONE
        updatePreview()
    }

    private fun decode(uri: Uri, maxSide: Int): Bitmap =
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > maxSide) {
                val s = maxSide.toFloat() / m
                dec.setTargetSize((info.size.width * s).toInt().coerceAtLeast(1), (info.size.height * s).toInt().coerceAtLeast(1))
            }
        }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 1) {
            try {
                srcUri = uri
                base = decode(uri, 900)
                result = null
                hint.visibility = View.GONE
                savedUri = null
                skStatus.text = ""; pStatus.text = ""
                for (b in listOf(skSave, skShare, skToVideo, generate)) { b.isEnabled = true; b.alpha = 1f }
                updatePreview()
                schedule()
            } catch (e: Throwable) {
                skStatus.text = "Gagal membuka foto: ${e.message}"
            }
        } else if (req == 2) {
            val f = File(filesDir, "hand_custom.png")
            try {
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, bo)
                if (bo.outWidth <= 0) { f.delete(); Toast.makeText(this, "File bukan gambar", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                f.delete(); Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            refreshHandInfo()
        }
    }
}
